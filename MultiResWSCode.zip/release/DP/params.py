# Generates parameters for some toy set-ups
import torch

# Single binary classification setting
# LF structure looks like this:
# lambda_0 - lambda_1 - lambda_2    lambda_3      lambda_4
def generate_params_chain_single_task(device):
    phi01 = torch.FloatTensor([[[0.90, 0.01],
                                [0.05, 0.01]],
                               [[0.04, 0.01],
                                [0.01, 0.97]]])
    phi12 = torch.FloatTensor([[[0.84, 0.01],
                                [0.10, 0.01]],
                               [[0.04, 0.06],
                                [0.02, 0.92]]])
    phi = torch.cat((phi01.unsqueeze(0), phi12.unsqueeze(0)))
    edges = [(0,1),(1,2)]
    
    mu = torch.zeros(5,2,2)
    mu[0,:,:] = phi01.sum(1)
    mu[1,:,:] = phi01.sum(0)
    mu[2,:,:] = phi12.sum(0)
    for i in range(3,5):
        accuracy = 0.95-i*0.05
        inaccuracy = 1-accuracy
        mu[i,:,:] = torch.FloatTensor([[accuracy, inaccuracy],[inaccuracy, accuracy]])
    
    alpha = torch.ones(5,2)
    for i in range(5):
        alpha[i,:] = 0.9-0.05*i

    output = {'mu':mu.to(device), 'phi':phi.to(device), 'alpha': alpha.to(device), 
              'sharing': {'mu': [[i,] for i in range(5)], 'phi':[[e] for e in edges]},
              'coverage': [[0],]*5,
              'edges':edges, 'm':5, 'T':1}
    return output

# Generates parameters for synthetic time-series data with LFs that label each frame.
# For any given frame, the LFs are conditionally independent on each other. 
# Example LF structure looks like this for m_per_task=3 and T=2:
#   lambda_0 - lambda_3
#   lambda_1 - lambda_4
#   lambda_2 - lambda_5
# In the above example, lambdas 0-2 label the first frame. 
def generate_temporal_params(m_per_task, T, device):
    m =  m_per_task * T
    coverage_sets = [[t,] for t in range(T) for i in range(m_per_task)]
    edges = [(t*m_per_task+i, (t+1)*m_per_task+i) for i in range(m_per_task) for t in range(T-1)]
    d = len(edges)
    param_sharing = {'mu': [[t*m_per_task+i for t in range(T)] for i in range(m_per_task)],
                     'phi': [[(t*m_per_task+i, (t+1)*m_per_task+i) for t in range(T-1)] for i in range(m_per_task)],
                     'alpha': [[t*m_per_task+i for t in range(T)] for i in range(m_per_task)]}

    phi_list = []
    mu_list = []
    for shared_edges in param_sharing['phi']:
        i,j = shared_edges[0]
        u = edges.index((i,j))
        accuracy = 0.94-(u//(T-1))*0.06
        inaccuracy = (1-accuracy)/3
        marginal_accuracy = accuracy + inaccuracy
        one_right = marginal_accuracy*(1-marginal_accuracy)
        both_right = marginal_accuracy**2
        both_wrong = (1-marginal_accuracy)**2
        phi = torch.FloatTensor([[[accuracy, one_right, one_right, inaccuracy],
                                  [inaccuracy, both_right, both_wrong, inaccuracy]],
                                 [[inaccuracy, both_wrong, both_right, inaccuracy],
                                  [inaccuracy, one_right, one_right, accuracy]]])
        phi_list.append(phi.to(device))
        mu = phi.sum(0)[:,0:2]
        mu_list.append(mu.to(device))

    alpha_list = []
    for shared_LFs in param_sharing['mu']:
        i = shared_LFs[0]
        alpha_list.append((0.7+0.05*(i%m_per_task))*torch.ones(2, device=device))
    
    output = {'mu':mu_list, 'phi':phi_list, 'alpha':alpha_list, 'sharing':param_sharing, 'edges':edges,
              'coverage': coverage_sets, 'm':m, 'T':T}
    return output
